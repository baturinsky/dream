(()=>{var Kt=Object.fromEntries(`Health:So called Hit Points:31
Strength:Dealing Damage:fg
Resilience:Damage reduction:qp
Greed:Find More:c4
Bloom:Regeneration:tu
Courage:Cover your allies:a9
Anger:Avenge Damage:cd
Mercy:Heal Friends:23
Knowledge:Writing and Reading:mn
Light:Strike True:lk
Dark:Avoid Damage:no
Time:Attack Rate:rq
Purity:Resist Poison:4u
Venom:Poison:ba`.split(`
`).map((t,e)=>{let[n,r,i]=t.split(":");return[n[0],{name:n,tip:r,colors:i}]})),d=Object.fromEntries(`Wood:67:H
Iron:32:S
Stone:mn:R
Gold:c4:G
Leaf:ba:B
Leather:56:C
Bone:ji:A
Cloth:tv:M
Paper:kl:K
Glass:wr:L
Obsidian:no:D
Copper:ef:T
Silver:lx:P
Asbestos:kb:V`.split(`
`).map(t=>{let[e,n,r]=t.split(":");return[e,{colors:n,aspect:r}]}));console.log(d);var $t=Object.fromEntries(`Door:2::Wood
Bed:2:H:Wood
Column:3:Stone
Apple:1:B:Leaf
Chair:2:H:Wood
Chest:1:G:Wood
Shelf:2:G:Wood
Stand:2:Stone
Display:2:Glass
Plaque:2::Iron
Table:2::Stone
Display2:2:Glass
Dial:2::Glass
Bench:2::Wood
Clock:1::Gold
Pedestal:1::Wood
Grave:1::Stone
Angel:2::Silver
Press:2::Iron
Brush:1::Cloth
Wine:1::Leaf`.split(`
`).map(t=>{let[e,n,r,i]=t.split(":");return[e,{scale:n,aspect:r,material:i}]}));console.log($t);var it=(t,e,n)=>kt(Dt(n,t),e),$=(t,e)=>it("S",t,e);var D=(t,e)=>it("O",t,e);function kt(t,e){if(!t)debugger;if(!e)return t;let n=t.cloneNode();return m(n).filter=Xt(e),m(n).drawImage(t,0,0),n}var I=32,Ht=48,wt=64;var at=wt,lt=Ht,rt=16;function Dt(t,e,n=0){e=="O"&&(n=1);let[r,i]=Z(E+n*2);return r.id=e+t,i.filter=`url(#_${e})`,i.drawImage(img,t%rt*E,~~(t/rt)*E,E,E,n,n,E,E),r}function m(t){return t.getContext("2d")}function Xt(t){if(!R.has(t)){R.add(t);let[e,n]=[...t].map(i=>T[Number.parseInt(i,36)]),r=`<filter id=f${t}><feColorMatrix type=matrix values="${e[0]} ${n[0]} 0 0 0  ${e[1]} ${n[1]} 0 0 0  ${e[2]} ${n[2]} 0 0 0  0 0 0 1 0" /></filter>`;DEFS.innerHTML+=r}return`url(#f${t})`}function Z(t,e){let n=document.createElement("canvas");return n.classList.add("sprite"),n.width=n.height=t,Object.assign(n,e),[n,m(n)]}var k=t=>m(t).createPattern(t,"repeat");function C(t,e,n=1){return t.map((r,i)=>r+e[i]*n)}function st(t,e=1){return t.map((n,r)=>n*e)}function X(t,e){return C(t,e,-1)}function Yt(t){return t.reduce((e,n)=>e+n*n,0)**.5}function O(t,e){return Yt(X(e,t))}var G=2**31,b=Bt(123);function Bt(t=0){0<t&&t<1&&(t=~~(t*G));let e=n=>(t=t*16807%2147483647)%n;return b=n=>n==-1?t:n==null?e(G)/G:e(n),b}function ct(t,e=b){if(!t)return null;let n=e(t.length);return t[n]}var z={bitPos:[[3,1],[2,14],[2,10],[2,13]],mountPoint:[0,0,16],size:[16,24],origin:"75% 50%",kind:1,makeBits:t=>[[t.shape,t.colors],[at,t.colors],It(t.body),[lt,t.colors]]},mt={bitPos:[[0,0]],size:[10,10],kind:3,makeBits:t=>t&&[[t.shape,t.colors]]},v={...mt,mountPoint:[5,0,0],kind:2},ae={...mt,kind:4};function W(t,e,n=0){let r=t.pos,i=Date.now(),o=O(t.pos,e)*10,l=e[0]-t.pos[0];l!=0&&(t.right=l>0);let f=X(e,r);return()=>{let c=Date.now(),S=Math.min(c-i,o);t.pos=C(r,f,o?S/o:1);let ot=S>=o||O(t.pos,e)<n;return t.transform=ot?"":`rotateZ(${Math.sin(c/100)*5}deg)`,!ot}}var At="scaleX(-1)";function H(t,e,n=0){let r=ft(t.pos),i=ft(e);return i==r?[()=>W(a,e,n)]:[()=>W(t,Y(r)),()=>t.pos=Y(i),()=>W(t,e,n)]}function pt(t){return[t.size[0]*t.scale,t.size[1]*t.scale]}function g(t,e){if(!t.animation){let l=t.actionsQueue.shift();if(l){let f=l();f instanceof Function&&(t.animation=f)}}t.animation&&t.animation()==!1&&delete t.animation;let n=t.div,r=e?C(t.pos,e):t.pos,i=X(r,Ft(t));n.style.left=`${i[0]}px`,n.style.top=`${i[2]}px`,n.style.opacity=t.opacity;let o=`translateZ(${r[1]}px)`+(t.right?At:"")+(t.transform??"");n.style.transform=o}function Ft(t){return[pt(t)[0]/2,0,pt(t)[1]]}function Rt(t){let[e]=Z(1),n=document.createElement("div");return n.classList.add("scont"),n.appendChild(e),n.style.position="absolute",e.id="s"+t.id,t.canvas=e,t.div=n,L(t),e}function It(t){return t&&[t.shape,t.colors]}function L(t){t.material&&(t.colors=d[t.material].colors),t.makeBits&&(t.bits=t.makeBits(t));let e=t.canvas,n=t.scale;if(e.width=t.size[0]*n,e.height=t.size[1]*n,e.style.transformOrigin=t.origin,m(e).imageSmoothingEnabled=!1,e.style.pointerEvents=t.noclick?"none":"all",t.bits)for(let r=0;t.bits[r];r++){let i=t.bits[r];if(!i||!i[0])continue;let o=D(i[1],i[0]);m(e).drawImage(o,t.bitPos[r][0]*n,t.bitPos[r][1]*n,o.width*n,o.height*n)}}var Zt=0;function x(t){t.id??=++Zt,t.held=[];let e={canvas:Rt(t),floor:0,scale:1,actionsQueue:[],...t};return L(e),e.pos&&(M.push(e),Scene.appendChild(e.div),g(e)),e}function N(t,e,n){e.kind==2&&(t.div.appendChild(e.div),t.held.unshift(e),e.parent=t,e.pos=n??st(t.mountPoint,t.scale),g(e))}function q(t,e){let n=t.held.shift();return n&&(n.pos=e??t.pos,Scene.appendChild(n.div),delete n.parent,g(n)),n}function ft(t){return~~(t[0]/u)+p*~~(t[2]/s-1)}function Y(t){return[(t%p+.5)*u,0,s*~~(t/p+1)]}function j(t,e){return{...v,shape:t,colors:e}}function ut(t,e){e&&(t.colors=e.colors,t.shape=e.shape,t.scale=e.scale),L(t)}function K(t){return w(t).pos}function w(t){return t.parent?w(t.parent):t}var Q=[],B=[-100,20],gt=600;function Gt(t,e){!t||(t.actionsQueue=e,delete t.animation)}function Ot(t){return[t[0],t[1],Math.ceil(t[2]/s)*s]}function dt(t,e){ut(h,t),h.pos=e,Scene.appendChild(h.div),g(h)}function V(){Scene.style.left=`${B[0]}px`,Scene.style.top=`${B[1]}px`}function xt(){onpointerup=t=>{Q[t.button]=!1},onpointerdown=t=>{Q[t.button]=!0;let[e,n,r,i]=A(t),o=[e,n,i*s],l;if(a&&r=="f"&&!t.shiftKey&&((t.button==0||t.button==2&&!a.held.length)&&(l=H(a,o)),t.button==2&&a.held.length&&(l=[...H(a,o),()=>q(a)])),a&&r=="s"&&!t.shiftKey){let c=M.find(S=>S.id==i);c&&c!=a&&(t.button==0&&(l=H(a,K(c),15)),t.button==2&&(w(c).kind==1&&J(w(c)),l=[...H(a,Ot(K(c))),()=>{if(a.held.length){let S=q(a);S&&N(c,S)}else N(a,c)}]))}l&&Gt(a,l),oncontextmenu=c=>{c.shiftKey||c.preventDefault()},t.target.classList.contains("sprite")},onmousemove=t=>{if(Q[1]){let f=.5;B=C(B,[t.movementX,t.movementY],f),V()}let[e,n,r,i]=A(t),o=[e,n,i*s],l=a?.held[0];if(l&&(r=="f"&&dt(l,o),r=="s")){let f=M.find(c=>c.id==i);if(f){let c=C(f.pos,[0,0,-f.canvas.height]);dt(l,c),f.div.parentElement?.appendChild(h.div)}}t.preventDefault()},onwheel=t=>{gt-=t.deltaY*.2,_()}}function _(){Scene.style.transform=`translateZ(${gt}px)`}function A(t){let[e,n,r]=[t.target.id,t.offsetX,t.offsetY],i=e[0],o=e.substring(1);return[n,r,i,o]}function U(t){return[...t.matchAll(/(\w\w)(\w\w)(\w\w)/g)].map(e=>e.slice(1,4).map(n=>Math.round(Number.parseInt(n,16)/255*35).toString(36)).join("")).join("")}function tt(t){return[...t.matchAll(/(\w)(\w)(\w)/g)].map(e=>[...e.slice(1,4).map(n=>~~(Number.parseInt(n,36)/36*100)/100),1])}var ht=`43002a
890027
d9243c
ff6157
ffb762
c76e46
73392e
34111f
030710
273b2d
458239
9cb93b
ffd832
ff823b
d1401f
7c191a
310c1b
833f34
eb9c6e
ffdaac
ffffe4
bfc3c6
6d8a8d
293b49
041528
033e5e
1c92a7
77d6c1
ffe0dc
ff88a9
c03b94
601761
ddffff
eeeeee
`;var Et="1",vt="2",St=0;function F([t,e,n,r]){return`rgba(${t*255},${e*255},${n*255},${r})`}function Wt(t){for(let e in t){let n=F(t[e]);console.log(`%c          %c ${Number(e).toString(36)} ${n}`,`color:#00; background:${n}`,"background:#fff")}console.log(d);for(let e in d){let[n,r]=[...d[e].colors].map(i=>T[Number.parseInt(i,36)]);console.log(`%c   %c %c ${e}`,`color:#00; background:${F(n)}`,`color:#00; background:${F(r)}`,"background:#fff")}}function zt(){for(let t in T){let e=F(T[t]),n=Number(t).toString(36);Debug.innerHTML+=`<div class=csel id="C${n}" style="background:${e}" oncontextmenu="return false;" >${n}</div>`}}function Tt(){Wt(T),zt();for(let t=0;t<256;t++)Debug.appendChild(D(0,t))}addEventListener("pointerdown",t=>{let[e,n,r,i]=A(t);if(r=="f"&&t.button==0&&t.shiftKey){let l=yt();l.pos=[e,n,i*s],g(l)}r=="O"&&(St=i),r=="C"&&(t.button==0?Et=i:vt=i),Preview.innerHTML="";let o=yt();Preview.appendChild(o.canvas)});addEventListener("keydown",t=>{t.code=="KeyD"&&Debug.classList.toggle("dn")});function yt(){return x({...v,kind:2,shape:St,colors:Et+vt,pos:[0,0,0]})}function Ct(){let t="";for(let o=0;o<=p;o++)t+=`<canvas class=wall  id=w${o} style="left:${o*u}px;height:${y*s}px;width:${P}px" 
    width=${P*2} height=${y*s*2} /></canvas>`;for(let o=0;o<=y;o++)t+=`<canvas class=floor id=f${o} style="top:${o*s}px;height:${P}px;width:${p*u}px" 
    width=${p*u*2} height=${P*2}></canvas>`;Scene.innerHTML+=t;for(let o of[Back,Front])o.width=u*p*2,o.height=s*y*2,o.style.width=`${u*p}px`,o.style.height=`${s*y}px`;Front.style.transform=`translateZ(${P}px)`;let e=k($("2f",1)),n=m(Back);n.fillStyle=e,n.fillRect(0,0,1e4,1e4),n=m(Front),n.fillStyle=k($("2g",1));for(let o=0;o<p;o++)n.fillRect(o*u*2-10,0,20,1e4);for(let o=0;o<y;o++)n.fillRect(0,o*s*2-10,1e4,20);let r=k($("gf",2));document.querySelectorAll(".wall").forEach(o=>{let l=m(o);l.fillStyle=r,l.fillRect(0,0,1e4,1e4)});let i=k($("rq",1));document.querySelectorAll(".floor").forEach(o=>{let l=m(o);l.fillStyle=i,l.fillRect(0,0,1e4,1e4)})}var P=64,y=5,p=3,s=100,u=200,E=8,Nt=y*p,T=tt(U(ht)),R=new Set,Ke,Pt,qt,h,nt,a,M=[];onload=()=>{img.onload=jt,img.src="16cols.gif"};function J(t){a&&(a.noclick=!1,L(a)),a=t,a.noclick=!0,L(a),a.div.appendChild(nt.div)}function jt(){Ct(),Tt(),_(),xt(),V();for(let t=0;t<Nt;t++)x({...v,shape:80,colors:"ef",kind:3,scale:2,pos:Y(t)});Pt=x({...z,shape:18,colors:"nm",body:j(I+2,"lk"),pos:[20,10,s]}),qt=x({...z,shape:26,colors:"qp",body:j(I+1,"ba"),pos:[40,10,s]}),h=x({...v,opacity:.5,shape:1,colors:"ab",pos:[0,0,0],noclick:!0}),h.canvas.classList.add("phantom");for(let t=0;t<300;t++)x({...v,shape:80+b(20),scale:b()>.5?2:1,material:ct(Object.keys(d)),kind:2,pos:[b(u*p),b(P),(b(y)+1)*s]});nt=x({...v,shape:8,colors:"ab",pos:[8,0,0]}),nt.div.classList.add("pointer"),J(Pt),Mt(0)}var Lt=0,et=0;function Mt(t){let e=t-Lt||1;Lt=t,et=et*.9+1e3/e*.1,FPS.innerText=`FPS: ${~~et}`,M.forEach(n=>(n.actionsQueue.length||n.animation)&&g(n)),requestAnimationFrame(Mt),a?.held.length||(h.div.style.opacity="0")}})();
//# sourceMappingURL=bundle.js.map
